<template>
    <div id="childId">
        子组件<br/>
        <!-- 占位和将来被替换，有点类似于 router-view -->
        <slot />
    </div>
</template>