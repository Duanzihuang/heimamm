// vue.config.js
module.exports = {
  // 选项...
  lintOnSave: false, // 关闭掉eslint的检查
  publicPath: './' // 更改访问打包资源的路径
};
